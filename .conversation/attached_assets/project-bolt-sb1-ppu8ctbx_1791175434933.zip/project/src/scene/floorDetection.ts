import { FLOOR_LEVELS, DECK, STAIRS, CONTAINMENT } from './constants';

/**
 * Returns the floor surface height at a given (x, z) position,
 * considering the player's current Y to disambiguate overlapping regions.
 */
export function getFloorHeightAt(x: number, z: number, currentY: number): number {
  const r = Math.sqrt(x * x + z * z);

  // Stairwell 2: main deck -> upper deck (along X at z≈19)
  // Player must be roughly in the main-to-upper height band
  if (x >= STAIRS.s2.xMin && x <= STAIRS.s2.xMax && z >= STAIRS.s2.zMin && z <= STAIRS.s2.zMax) {
    const t = (x - STAIRS.s2.xMin) / (STAIRS.s2.xMax - STAIRS.s2.xMin);
    const stairY = STAIRS.s2.yStart + t * (STAIRS.s2.yEnd - STAIRS.s2.yStart);
    if (currentY > 10 && currentY < 42) return stairY;
  }

  // Stairwell 1: basement -> main deck (along Z at x≈19)
  if (x >= STAIRS.s1.xMin && x <= STAIRS.s1.xMax && z >= STAIRS.s1.zMin && z <= STAIRS.s1.zMax) {
    const t = (z - STAIRS.s1.zMin) / (STAIRS.s1.zMax - STAIRS.s1.zMin);
    const stairY = STAIRS.s1.yStart + t * (STAIRS.s1.yEnd - STAIRS.s1.yStart);
    if (currentY > -10 && currentY < 22) return stairY;
  }

  // Upper deck: circular ring with central hole
  if (r <= DECK.outerRadius && r > DECK.upperHoleRadius && currentY > 25) {
    return DECK.upperY;
  }

  // Main deck: circular ring with central hole for RPV cavity
  if (r <= DECK.outerRadius && r > DECK.mainHoleRadius && currentY > 5 && currentY < 30) {
    return DECK.mainY;
  }

  // Basement room: enclosed area under containment
  if (x >= -14 && x <= 14 && z >= -14 && z <= 14 && currentY < 10) {
    return FLOOR_LEVELS.basement;
  }

  // Exterior ground
  return FLOOR_LEVELS.ground;
}

/** Walkable XZ bounds for clamping the player */
export function clampPlayerPosition(x: number, z: number): [number, number] {
  const r = Math.sqrt(x * x + z * z);
  const maxR = CONTAINMENT.innerRadius - 0.5;
  // Inside containment: allow up to inner radius
  // Outside: allow roaming on the site
  if (r > maxR && r < 60) {
    // Outside the containment but on site — allow it
    return [x, z];
  }
  if (r > 60) {
    // Clamp to site boundary
    const scale = 60 / r;
    return [x * scale, z * scale];
  }
  return [x, z];
}
