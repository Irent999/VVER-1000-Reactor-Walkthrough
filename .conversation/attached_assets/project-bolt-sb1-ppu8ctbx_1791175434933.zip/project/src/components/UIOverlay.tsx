import { useState, useEffect } from 'react';
import {
  Monitor, Layers, Radio, Info, X, Cpu, Gauge, Activity, Zap, Thermometer,
  Droplets, Globe2, Eye, Footsteps, Crosshair, Maximize2,
} from 'lucide-react';
import { ELEVATIONS, FLOOR_VIEWS, POI_LIST, type POIInfo, type ViewMode } from '@/data/poiData';
import type { TelemetrySnapshot } from '@/hooks/useTelemetry';

interface UIOverlayProps {
  activeView: string;
  onViewChange: (viewId: string) => void;
  containmentOpacity: number;
  onContainmentOpacityChange: (v: number) => void;
  controlMode: ViewMode;
  onVRClick: () => void;
  vrSupported: boolean | null;
  telemetry: TelemetrySnapshot;
  onPOISelect: (poi: POIInfo) => void;
}

function StatusDot({ active }: { active: boolean }) {
  return (
    <span
      className="inline-block w-2 h-2 rounded-full"
      style={{
        background: active ? '#06d6a0' : '#ff3333',
        boxShadow: active ? '0 0 6px #06d6a0' : '0 0 6px #ff3333',
        animation: 'pulse 1.5s ease-in-out infinite',
      }}
    />
  );
}

function TelemetryRow({ icon: Icon, label, value, unit, color }: {
  icon: React.ElementType; label: string; value: string; unit: string; color: string;
}) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-800/50 border border-slate-700/50">
      <Icon size={16} style={{ color }} className="shrink-0" />
      <div className="flex-1 min-w-0">
        <div className="text-[10px] text-slate-400 uppercase tracking-wider truncate">{label}</div>
        <div className="text-sm font-mono font-semibold text-slate-100">
          {value} <span className="text-slate-400 text-xs">{unit}</span>
        </div>
      </div>
    </div>
  );
}

function InfoModal({ poi, onClose }: { poi: POIInfo; onClose: () => void }) {
  const [lang, setLang] = useState<'en' | 'ru'>('en');
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div
        className="max-w-lg w-full bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto"
        style={{ borderColor: poi.color + '80', boxShadow: `0 0 40px ${poi.color}30` }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative px-6 py-4 border-b border-slate-700" style={{ background: `linear-gradient(135deg, ${poi.color}25, transparent)` }}>
          <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-white transition">
            <X size={20} />
          </button>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded text-xs font-semibold uppercase tracking-wide" style={{ background: poi.color + '30', color: poi.color }}>
              {lang === 'en' ? poi.categoryEn : poi.categoryRu}
            </span>
          </div>
          <h2 className="text-xl font-bold text-white">{lang === 'en' ? poi.titleEn : poi.titleRu}</h2>
        </div>
        <div className="flex gap-1 px-6 pt-3">
          {(['en', 'ru'] as const).map((l) => (
            <button
              key={l}
              onClick={() => setLang(l)}
              className={`px-3 py-1 text-xs rounded-md font-medium transition ${lang === l ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              {l === 'en' ? 'English' : 'Русский'}
            </button>
          ))}
        </div>
        <div className="px-6 py-3 grid grid-cols-2 gap-2">
          {poi.specs.map((spec, i) => (
            <div key={i} className="px-3 py-2 rounded-lg bg-slate-800/60 border border-slate-700/50">
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">{lang === 'en' ? spec.labelEn : spec.labelRu}</div>
              <div className="text-sm font-mono font-semibold" style={{ color: poi.color }}>{spec.value}</div>
            </div>
          ))}
        </div>
        <div className="px-6 pb-6">
          <p className="text-sm text-slate-300 leading-relaxed">{lang === 'en' ? poi.descriptionEn : poi.descriptionRu}</p>
        </div>
      </div>
    </div>
  );
}

export default function UIOverlay({
  activeView,
  onViewChange,
  containmentOpacity,
  onContainmentOpacityChange,
  controlMode,
  onVRClick,
  vrSupported,
  telemetry,
  onPOISelect,
}: UIOverlayProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const fmt = (v: number, d = 1) => v.toFixed(d);

  return (
    <>
      <style>{`@keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.4; } } @keyframes crosshair-pulse { 0%,100% { opacity: 0.5; } 50% { opacity: 0.9; } }`}</style>

      {/* Top bar */}
      <div className="fixed top-0 left-0 right-0 z-40 px-4 py-3 flex items-center justify-between bg-gradient-to-b from-slate-900/80 to-transparent pointer-events-none">
        <div className="flex items-center gap-2 pointer-events-auto">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900/80 border border-slate-700">
            <Activity size={18} className="text-cyan-400" />
            <span className="text-sm font-bold text-white">VVER-1000 Digital Twin</span>
            <span className="text-xs text-slate-400 hidden sm:inline">| Uzbekistan NPP</span>
          </div>
        </div>
        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 rounded-lg bg-slate-900/80 border border-slate-700 text-slate-300 hover:text-white hover:border-slate-500 transition"
          >
            <Layers size={18} />
          </button>
        </div>
      </div>

      {/* Crosshair in walk mode */}
      {controlMode === 'walk' && (
        <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-30 pointer-events-none" style={{ animation: 'crosshair-pulse 2s ease-in-out infinite' }}>
          <div className="relative w-6 h-6">
            <div className="absolute top-1/2 left-0 w-2 h-[1px] bg-cyan-300" />
            <div className="absolute top-1/2 right-0 w-2 h-[1px] bg-cyan-300" />
            <div className="absolute left-1/2 top-0 h-2 w-[1px] bg-cyan-300" />
            <div className="absolute left-1/2 bottom-0 h-2 w-[1px] bg-cyan-300" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1 h-1 rounded-full bg-cyan-300" />
          </div>
        </div>
      )}

      {/* "Click to Walk Around" prompt */}
      {controlMode === 'walk' && (
        <div
          id="lock-anchor"
          className="fixed bottom-20 left-1/2 -translate-x-1/2 z-30 px-5 py-2.5 rounded-xl bg-slate-900/85 border border-cyan-500/40 text-cyan-200 text-sm backdrop-blur-md cursor-pointer hover:bg-slate-800/90 transition flex items-center gap-2"
        >
          <Crosshair size={16} />
          Click to Walk Around · <span className="text-slate-400">WASD + Mouse</span>
        </div>
      )}

      {/* Sidebar */}
      <div className={`fixed top-16 left-0 z-30 w-72 max-h-[calc(100vh-4rem)] overflow-y-auto transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="m-3 p-4 rounded-xl bg-slate-900/85 border border-slate-700 backdrop-blur-md space-y-4">

          {/* View / Floor navigation */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Maximize2 size={14} className="text-cyan-400" />
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Navigation</h3>
            </div>
            <div className="space-y-1.5">
              {FLOOR_VIEWS.map((view) => {
                const isWalk = view.mode === 'walk';
                return (
                  <button
                    key={view.id}
                    onClick={() => onViewChange(view.id)}
                    className={`w-full flex items-center gap-2 text-left px-3 py-2 rounded-lg text-sm transition border ${
                      activeView === view.id
                        ? 'bg-cyan-500/20 border-cyan-500/60 text-cyan-300'
                        : 'bg-slate-800/50 border-slate-700/50 text-slate-300 hover:border-slate-500'
                    }`}
                  >
                    {isWalk ? <Footsteps size={14} className="shrink-0" /> : <Eye size={14} className="shrink-0" />}
                    {view.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Containment opacity */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Containment Shell</h3>
              <span className="text-xs font-mono text-cyan-300">{Math.round(containmentOpacity * 100)}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={containmentOpacity}
              onChange={(e) => onContainmentOpacityChange(parseFloat(e.target.value))}
              className="w-full accent-cyan-500"
            />
          </div>

          {/* VR launch */}
          <div>
            <button
              onClick={onVRClick}
              className={`w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg text-sm font-semibold transition border ${
                vrSupported
                  ? 'bg-emerald-500/20 border-emerald-500/60 text-emerald-300 hover:bg-emerald-500/30'
                  : 'bg-slate-800/50 border-slate-700/50 text-slate-400'
              }`}
            >
              <Radio size={16} />
              {vrSupported === null ? 'Detecting VR...' : vrSupported ? 'Enter VR Mode' : 'VR Not Available'}
            </button>
            {vrSupported === false && (
              <p className="text-[10px] text-slate-500 mt-1 text-center">WebXR device required (Meta Quest / HTC Vive)</p>
            )}
          </div>

          {/* Telemetry dashboard */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Monitor size={14} className="text-emerald-400" />
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Live Telemetry</h3>
              <StatusDot active={telemetry.safetyMode === 'NORMAL'} />
            </div>
            <div className="space-y-1.5">
              <TelemetryRow icon={Zap} label="Neutron Flux" value={fmt(telemetry.neutronFlux, 1)} unit="% nom" color="#fcbf49" />
              <TelemetryRow icon={Thermometer} label="Primary Temp" value={fmt(telemetry.primaryTemp, 1)} unit="°C" color="#ff6b35" />
              <TelemetryRow icon={Gauge} label="Primary Pressure" value={fmt(telemetry.primaryPressure, 2)} unit="MPa" color="#f77f00" />
              <TelemetryRow icon={Droplets} label="Flow Rate" value={fmt(telemetry.flowRate, 1)} unit="% nom" color="#4cc9f0" />
              <TelemetryRow icon={Activity} label="Steam Pressure" value={fmt(telemetry.steamPressure, 2)} unit="MPa" color="#06d6a0" />
              <TelemetryRow icon={Zap} label="Grid Output" value={fmt(telemetry.gridPower, 0)} unit="MWe" color="#a8dadc" />
            </div>
          </div>

          {/* DCS Bus status */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Cpu size={14} className="text-cyan-400" />
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">DCS Bus Status (2/4)</h3>
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {(['A', 'B', 'C', 'D'] as const).map((b, i) => {
                const active = i === 0 ? telemetry.dcsBusA : i === 1 ? telemetry.dcsBusB : i === 2 ? telemetry.dcsBusC : telemetry.dcsBusD;
                return (
                  <div key={b} className="flex flex-col items-center py-1.5 rounded-lg bg-slate-800/50 border border-slate-700/50">
                    <StatusDot active={active} />
                    <span className="text-[10px] mt-1 text-slate-400">Train {b}</span>
                  </div>
                );
              })}
            </div>
            <div className="mt-1.5 flex items-center justify-between px-2 py-1 rounded-lg bg-slate-800/50">
              <span className="text-[10px] text-slate-400 uppercase">Safety Mode</span>
              <span className={`text-xs font-mono font-bold ${telemetry.safetyMode === 'NORMAL' ? 'text-emerald-400' : 'text-amber-400'}`}>
                {telemetry.safetyMode}
              </span>
            </div>
          </div>

          {/* POI quick list */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Info size={14} className="text-slate-300" />
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Points of Interest</h3>
            </div>
            <div className="space-y-1">
              {POI_LIST.map((poi) => (
                <button
                  key={poi.id}
                  onClick={() => onPOISelect(poi)}
                  className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs text-slate-300 hover:bg-slate-800/70 transition"
                >
                  <span className="w-2 h-2 rounded-full shrink-0" style={{ background: poi.color, boxShadow: `0 0 6px ${poi.color}` }} />
                  {poi.titleEn}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-1.5 pt-1 border-t border-slate-700/50">
            <Globe2 size={12} className="text-slate-500" />
            <span className="text-[10px] text-slate-500">Uzbekistan NPP · VVER-1000 V-392M · 1:1 Scale</span>
          </div>
        </div>
      </div>
    </>
  );
}
